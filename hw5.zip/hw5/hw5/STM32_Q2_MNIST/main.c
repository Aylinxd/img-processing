
#include "main.h"
#include "stm32_models/mnist_mlp_model_config.h"
#include "stm32_models/hu_moments.h"
#include "stm32_models/normalization_params.h"
#include "stm32_models/neural_network.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

UART_HandleTypeDef huart2;

/* Private function prototypes */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);

/**
  * @brief  Process image and predict digit
  * @param  image: Input image buffer (28x28 pixels)
  * @retval Predicted digit (0-9)
  */
int predict_digit(const uint8_t* image) {
    float hu_moments[7];
    float predictions[10];
    int predicted_digit;
    int i;
    
    // Extract Hu moments from image
    extract_hu_moments(image, 28, 28, hu_moments);
    
    // Normalize features
    normalize_hu_moments(hu_moments, HU_MOMENTS_MEAN, HU_MOMENTS_STD);
    
    // Run neural network inference
    neural_network_predict(&mnist_mlp_model, hu_moments, predictions);
    
    // Find predicted class (digit with highest probability)
    predicted_digit = 0;
    for (i = 1; i < 10; i++) {
        if (predictions[i] > predictions[predicted_digit]) {
            predicted_digit = i;
        }
    }
    
    return predicted_digit;
}


void print_prediction(const uint8_t* image) {
    float hu_moments[7];
    float predictions[10];
    int predicted_digit;
    char msg[200];
    int i;
    
    // Extract and normalize features
    extract_hu_moments(image, 28, 28, hu_moments);
    normalize_hu_moments(hu_moments, HU_MOMENTS_MEAN, HU_MOMENTS_STD);
    
    // Run inference
    neural_network_predict(&mnist_mlp_model, hu_moments, predictions);
    
    // Find predicted digit
    predicted_digit = 0;
    for (i = 1; i < 10; i++) {
        if (predictions[i] > predictions[predicted_digit]) {
            predicted_digit = i;
        }
    }
    
    // Format output message
    sprintf(msg, "\r\n=== Digit Recognition Result ===\r\n");
    HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
    
    sprintf(msg, "Predicted Digit: %d\r\n", predicted_digit);
    HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
    
    sprintf(msg, "Probabilities:\r\n");
    HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
    
    for (i = 0; i < 10; i++) {
        sprintf(msg, "  Digit %d: %.2f%%\r\n", i, predictions[i] * 100.0f);
        HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
    }
    
    sprintf(msg, "==============================\r\n\r\n");
    HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
}


void test_with_sample_image(void) {

    uint8_t test_image[28 * 28];
    int i;
    
 
    memset(test_image, 0, sizeof(test_image));

    for (i = 0; i < 28 * 28; i++) {
        test_image[i] = (i % 2) * 255;  // Simple pattern
    }
    
    print_prediction(test_image);
}


int main(void) {

    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_USART2_UART_Init();
    
    char welcome_msg[] = "\r\n\r\n=== STM32 MNIST Digit Recognition ===\r\n";
    HAL_UART_Transmit(&huart2, (uint8_t*)welcome_msg, strlen(welcome_msg), HAL_MAX_DELAY);
    
    char ready_msg[] = "System ready. Waiting for image...\r\n\r\n";
    HAL_UART_Transmit(&huart2, (uint8_t*)ready_msg, strlen(ready_msg), HAL_MAX_DELAY);
    
    /* Infinite loop */
    while (1) {        
        HAL_Delay(1000);
    }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void) {
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
    RCC_OscInitStruct.PLL.PLLM = 1;
    RCC_OscInitStruct.PLL.PLLN = 10;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
    RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
    RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
        Error_Handler();
    }
    
    /** Initializes the CPU, AHB and APB buses clocks
    */
    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                                |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK) {
        Error_Handler();
    }
}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void) {
    huart2.Instance = USART2;
    huart2.Init.BaudRate = 115200;
    huart2.Init.WordLength = UART_WORDLENGTH_8B;
    huart2.Init.StopBits = UART_STOPBITS_1;
    huart2.Init.Parity = UART_PARITY_NONE;
    huart2.Init.Mode = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart2) != HAL_OK) {
        Error_Handler();
    }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    
    /* GPIO Ports Clock Enable */
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    
    /*Configure GPIO pin : User Button (PC13 for Nucleo) */
    GPIO_InitStruct.Pin = GPIO_PIN_13;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void) {
    __disable_irq();
    while (1) {
    }
}

#ifdef  USE_FULL_ASSERT

void assert_failed(uint8_t *file, uint32_t line) {

}
#endif /* USE_FULL_ASSERT */

