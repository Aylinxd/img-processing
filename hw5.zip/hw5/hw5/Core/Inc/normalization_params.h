/*
 * Normalization Parameters for Hu Moments Features
 * Extracted from MNIST training dataset
 * Used for feature normalization: (x - mean) / std
 */

#ifndef NORMALIZATION_PARAMS_H
#define NORMALIZATION_PARAMS_H

#include <stdint.h>

const float HU_MOMENTS_MEAN[7] = {
    0.33422612f,
    0.04476821f,
    0.00818686f,
    0.00141505f,
    0.00000671f,
    0.00015559f,
    -0.00000646f
};

const float HU_MOMENTS_STD[7] = {
    0.08404617f,
    0.06376581f,
    0.01406146f,
    0.00258284f,
    0.00008245f,
    0.00072079f,
    0.00006312f
};

#define NUM_HU_MOMENTS 7

#endif // NORMALIZATION_PARAMS_H
