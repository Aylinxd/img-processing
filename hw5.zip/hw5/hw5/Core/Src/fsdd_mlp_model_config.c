/**
  ******************************************************************************
  * @file    fsdd_mlp_model_config.c
  * @brief   fsdd_mlp model configuration for STM32
  *          Auto-generated from mlp_fsdd_model.h5
  ******************************************************************************
  */

#include "fsdd_mlp_model_config.h"
#include "neural_network.h"
#include "fsdd_mlp_model.h"

/* Layer 0 configuration */
static const LayerConfig layer0 = {
    .weights = fsdd_mlp_layer0_weights,
    .biases = fsdd_mlp_layer0_biases,
    .input_size = FSDD_MLP_LAYER0_INPUT_SIZE,
    .output_size = FSDD_MLP_LAYER0_OUTPUT_SIZE,
    .activation = ACTIVATION_RELU
};

/* Layer 1 configuration */
static const LayerConfig layer1 = {
    .weights = fsdd_mlp_layer1_weights,
    .biases = fsdd_mlp_layer1_biases,
    .input_size = FSDD_MLP_LAYER1_INPUT_SIZE,
    .output_size = FSDD_MLP_LAYER1_OUTPUT_SIZE,
    .activation = ACTIVATION_RELU
};

/* Layer 2 configuration */
static const LayerConfig layer2 = {
    .weights = fsdd_mlp_layer2_weights,
    .biases = fsdd_mlp_layer2_biases,
    .input_size = FSDD_MLP_LAYER2_INPUT_SIZE,
    .output_size = FSDD_MLP_LAYER2_OUTPUT_SIZE,
    .activation = ACTIVATION_SOFTMAX
};

static const LayerConfig* layers[FSDD_MLP_NUM_LAYERS] = {
    &layer0,
    &layer1,
    &layer2
};

/* Model structure */
const NeuralNetworkModel fsdd_mlp_model = {
    .layers = (const LayerConfig*)layers,
    .num_layers = FSDD_MLP_NUM_LAYERS,
    .input_size = FSDD_MLP_INPUT_SIZE,
    .output_size = FSDD_MLP_OUTPUT_SIZE
};
