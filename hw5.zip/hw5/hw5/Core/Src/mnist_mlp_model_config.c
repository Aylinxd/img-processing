/**
  ******************************************************************************
  * @file    mnist_mlp_model_config.c
  * @brief   mnist_mlp model configuration for STM32
  *          Auto-generated from mlp_mnist_model.h5
  ******************************************************************************
  */

#include "mnist_mlp_model_config.h"
#include "neural_network.h"
#include "mnist_mlp_model.h"

/* Layer 0 configuration */
static const LayerConfig layer0 = {
    .weights = mnist_mlp_layer0_weights,
    .biases = mnist_mlp_layer0_biases,
    .input_size = MNIST_MLP_LAYER0_INPUT_SIZE,
    .output_size = MNIST_MLP_LAYER0_OUTPUT_SIZE,
    .activation = ACTIVATION_RELU
};

/* Layer 1 configuration */
static const LayerConfig layer1 = {
    .weights = mnist_mlp_layer1_weights,
    .biases = mnist_mlp_layer1_biases,
    .input_size = MNIST_MLP_LAYER1_INPUT_SIZE,
    .output_size = MNIST_MLP_LAYER1_OUTPUT_SIZE,
    .activation = ACTIVATION_RELU
};

/* Layer 2 configuration */
static const LayerConfig layer2 = {
    .weights = mnist_mlp_layer2_weights,
    .biases = mnist_mlp_layer2_biases,
    .input_size = MNIST_MLP_LAYER2_INPUT_SIZE,
    .output_size = MNIST_MLP_LAYER2_OUTPUT_SIZE,
    .activation = ACTIVATION_SOFTMAX
};

static const LayerConfig* layers[MNIST_MLP_NUM_LAYERS] = {
    &layer0,
    &layer1,
    &layer2
};

/* Model structure */
const NeuralNetworkModel mnist_mlp_model = {
    .layers = (const LayerConfig*)layers,
    .num_layers = MNIST_MLP_NUM_LAYERS,
    .input_size = MNIST_MLP_INPUT_SIZE,
    .output_size = MNIST_MLP_OUTPUT_SIZE
};
