/**
  ******************************************************************************
  * @file    hu_moments.c
  * @brief   Hu Moments feature extraction for STM32
  *          Extracts 7 Hu moments from binary image
  ******************************************************************************
  */

#include "hu_moments.h"
#include <math.h>
#include <string.h>

/**
  * @brief  Calculate image moments
  * @param  image: Input image (28x28 for MNIST)
  * @param  width: Image width
  * @param  height: Image height
  * @param  moments: Output moments structure
  * @retval None
  */
void calculate_moments(const uint8_t* image, int width, int height, ImageMoments* moments) {
    int x, y;
    float m00 = 0.0f, m01 = 0.0f, m10 = 0.0f;
    float m11 = 0.0f, m02 = 0.0f, m20 = 0.0f;
    float m12 = 0.0f, m21 = 0.0f, m03 = 0.0f, m30 = 0.0f;
    
    // Calculate raw moments
    for (y = 0; y < height; y++) {
        for (x = 0; x < width; x++) {
            float pixel = (float)image[y * width + x];
            float xf = (float)x;
            float yf = (float)y;
            
            m00 += pixel;
            m10 += xf * pixel;
            m01 += yf * pixel;
            m11 += xf * yf * pixel;
            m20 += xf * xf * pixel;
            m02 += yf * yf * pixel;
            m21 += xf * xf * yf * pixel;
            m12 += xf * yf * yf * pixel;
            m30 += xf * xf * xf * pixel;
            m03 += yf * yf * yf * pixel;
        }
    }
    
    // Calculate centroid
    float cx = m10 / m00;
    float cy = m01 / m00;
    
    // Calculate central moments (normalized)
    float mu20 = m20 / m00 - cx * cx;
    float mu02 = m02 / m00 - cy * cy;
    float mu11 = m11 / m00 - cx * cy;
    float mu30 = m30 / m00 - 3.0f * cx * m20 / m00 + 2.0f * cx * cx * cx;
    float mu03 = m03 / m00 - 3.0f * cy * m02 / m00 + 2.0f * cy * cy * cy;
    float mu21 = m21 / m00 - 2.0f * cx * m11 / m00 - cy * m20 / m00 + 2.0f * cx * cx * cy;
    float mu12 = m12 / m00 - 2.0f * cy * m11 / m00 - cx * m02 / m00 + 2.0f * cx * cy * cy;
    
    // Store moments
    moments->m00 = m00;
    moments->mu20 = mu20;
    moments->mu02 = mu02;
    moments->mu11 = mu11;
    moments->mu30 = mu30;
    moments->mu03 = mu03;
    moments->mu21 = mu21;
    moments->mu12 = mu12;
}

/**
  * @brief  Calculate Hu moments from image moments
  * @param  moments: Image moments structure
  * @param  hu_moments: Output array for 7 Hu moments
  * @retval None
  */
void calculate_hu_moments(const ImageMoments* moments, float* hu_moments) {
    float mu20 = moments->mu20;
    float mu02 = moments->mu02;
    float mu11 = moments->mu11;
    float mu30 = moments->mu30;
    float mu03 = moments->mu03;
    float mu21 = moments->mu21;
    float mu12 = moments->mu12;
    
    // Hu moment 1: eta20 + eta02
    hu_moments[0] = mu20 + mu02;
    
    // Hu moment 2: (eta20 - eta02)^2 + 4*eta11^2
    float diff = mu20 - mu02;
    hu_moments[1] = diff * diff + 4.0f * mu11 * mu11;
    
    // Hu moment 3: (eta30 - 3*eta12)^2 + (3*eta21 - eta03)^2
    float term1 = mu30 - 3.0f * mu12;
    float term2 = 3.0f * mu21 - mu03;
    hu_moments[2] = term1 * term1 + term2 * term2;
    
    // Hu moment 4: (eta30 + eta12)^2 + (eta21 + eta03)^2
    term1 = mu30 + mu12;
    term2 = mu21 + mu03;
    hu_moments[3] = term1 * term1 + term2 * term2;
    
    // Hu moment 5: (eta30 - 3*eta12)*(eta30 + eta12)*[(eta30 + eta12)^2 - 3*(eta21 + eta03)^2]
    //              + (3*eta21 - eta03)*(eta21 + eta03)*[3*(eta30 + eta12)^2 - (eta21 + eta03)^2]
    float eta30_3eta12 = mu30 - 3.0f * mu12;
    float eta30_eta12 = mu30 + mu12;
    float eta21_eta03 = mu21 + mu03;
    float eta3eta21_eta03 = 3.0f * mu21 - mu03;
    float term1_sq = eta30_eta12 * eta30_eta12;
    float term2_sq = eta21_eta03 * eta21_eta03;
    
    hu_moments[4] = eta30_3eta12 * eta30_eta12 * (term1_sq - 3.0f * term2_sq) +
                    eta3eta21_eta03 * eta21_eta03 * (3.0f * term1_sq - term2_sq);
    
    // Hu moment 6: (eta20 - eta02)*[(eta30 + eta12)^2 - (eta21 + eta03)^2]
    //              + 4*eta11*(eta30 + eta12)*(eta21 + eta03)
    hu_moments[5] = diff * (term1_sq - term2_sq) + 4.0f * mu11 * eta30_eta12 * eta21_eta03;
    
    // Hu moment 7: (3*eta21 - eta03)*(eta30 + eta12)*[(eta30 + eta12)^2 - 3*(eta21 + eta03)^2]
    //              - (eta30 - 3*eta12)*(eta21 + eta03)*[3*(eta30 + eta12)^2 - (eta21 + eta03)^2]
    hu_moments[6] = eta3eta21_eta03 * eta30_eta12 * (term1_sq - 3.0f * term2_sq) -
                    eta30_3eta12 * eta21_eta03 * (3.0f * term1_sq - term2_sq);
}

/**
  * @brief  Extract Hu moments from image
  * @param  image: Input image (28x28 for MNIST)
  * @param  width: Image width
  * @param  height: Image height
  * @param  hu_moments: Output array for 7 Hu moments
  * @retval None
  */
void extract_hu_moments(const uint8_t* image, int width, int height, float* hu_moments) {
    ImageMoments moments;
    calculate_moments(image, width, height, &moments);
    calculate_hu_moments(&moments, hu_moments);
}

/**
  * @brief  Normalize Hu moments using mean and std
  * @param  hu_moments: Input/output Hu moments array (7 elements)
  * @param  mean: Mean values for normalization
  * @param  std: Standard deviation values for normalization
  * @retval None
  */
void normalize_hu_moments(float* hu_moments, const float* mean, const float* std) {
    int i;
    for (i = 0; i < 7; i++) {
        hu_moments[i] = (hu_moments[i] - mean[i]) / std[i];
    }
}

