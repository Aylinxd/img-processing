
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32l4xx_hal.h"

/* Exported constants */
#define AUDIO_BUFFER_SIZE 1600  // 100ms at 16kHz
#define FEATURE_SIZE 13         // MFCC feature size (adjust as needed)
#define NUM_KEYWORDS 10          // Number of keyword classes
#define DETECTION_THRESHOLD 0.5f // Minimum probability for detection

/* Exported functions */
void Error_Handler(void);

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

