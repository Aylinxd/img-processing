# How to Convert Markdown to Word

## Method 1: Online Converter (Easiest)

1. Go to: https://www.markdowntoword.com/ or https://cloudconvert.com/md-to-docx
2. Upload `REPORT_EN.md` file
3. Download the converted Word document

## Method 2: Using Pandoc (Recommended)

If you have Pandoc installed:

```bash
pandoc REPORT_EN.md -o REPORT_EN.docx
```

## Method 3: Copy-Paste to Word

1. Open `REPORT_EN.md` in a Markdown viewer (GitHub, VS Code preview, etc.)
2. Copy the rendered content
3. Paste into Microsoft Word
4. Format as needed

## Method 4: Using VS Code Extension

1. Install "Markdown PDF" extension in VS Code
2. Open `REPORT_EN.md`
3. Right-click → "Markdown PDF: Export (docx)"

