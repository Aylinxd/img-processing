# EE 4065 - Embedded Digital Image Processing Homework 2
## Rapor

**Tarih:** 2025  
**Mikrodenleyici:** STM32F446RE  
**Görüntü Boyutu:** 128×128 piksel (16,384 piksel)  
**Geliştirme Ortamı:** STM32CubeIDE

---

## 1. Özet

Bu ödevde, STM32F446RE mikrodenleyicisi üzerinde grayscale görüntü işleme algoritmaları implement edilmiştir. Gerçekleştirilen işlemler:

1. **Histogram Oluşturma (Q1)**
2. **Histogram Eşitleme (Q2)**
3. **2D Konvolüsyon ve Filtreleme (Q3)** - Low-pass ve High-pass filtreler
4. **Median Filtreleme (Q4)**

Tüm işlemler 128×128 piksel grayscale görüntü üzerinde gerçekleştirilmiştir. RAM kullanımını optimize etmek için, tam görüntü yerine sadece ilk 1024 piksel RAM'de saklanmıştır.

---

## 2. Sistem Özellikleri

### 2.1 Donanım
- **Mikrodenleyici:** STM32F446RE (Cortex-M4, 180 MHz)
- **RAM:** 128 KB
- **Flash:** 512 KB
- **Debug Interface:** ST-Link

### 2.2 Yazılım
- **IDE:** STM32CubeIDE
- **Derleyici:** ARM GCC (arm-none-eabi-gcc)
- **HAL Library:** STM32F4xx HAL Driver

### 2.3 Görüntü Özellikleri
- **Boyut:** 128×128 piksel
- **Format:** 8-bit grayscale (0-255)
- **Toplam Piksel:** 16,384
- **Kaynak:** `mouse_image.h` header dosyası

---

## 3. Q1: Histogram Oluşturma (20 puan)

### 3.1 Teorik Açıklama

Histogram, bir görüntüdeki her piksel değerinin (0-255 arası) kaç kez tekrarlandığını gösteren bir istatistiksel dağılımdır. Grayscale görüntüler için histogram, görüntünün parlaklık dağılımını analiz etmek için kullanılır.

**Matematiksel Tanım:**
```
H(i) = piksel değeri i'ye sahip piksel sayısı
i ∈ [0, 255]
```

### 3.2 Implementasyon

```c
static void compute_histogram(const uint8_t* img, int w, int h, uint32_t hist[256]) {
  // Histogram dizisini sıfırla
  for (int i = 0; i < 256; ++i) hist[i] = 0;

  // Tüm pikselleri tara ve histogramı oluştur
  for (int y = 0; y < h; ++y) {
    for (int x = 0; x < w; ++x) {
      uint8_t p = img[y * w + x];
      hist[p]++;
    }
  }
}
```

**Algoritma:**
1. 256 elemanlı histogram dizisi sıfırlanır
2. Görüntünün her pikseli taranır
3. Her piksel değeri için ilgili histogram bin'i artırılır

**Karmaşıklık:** O(W×H) = O(16,384) işlem

### 3.3 Sonuçlar

- **Çıktı:** `hist_original[256]` dizisi
- **Veri Tipi:** `volatile uint32_t[256]`
- **Toplam:** Tüm histogram değerlerinin toplamı = 16,384 (görüntü boyutu)

**STM32CubeIDE'de Görüntüleme:**
- Expressions penceresinde `hist_original` değişkeni eklenir
- `hist_original[0]` ile `hist_original[255]` arasındaki değerler incelenebilir
- Örnek: `hist_original[128]` → görüntüde 128 değerine sahip piksel sayısı

---

## 4. Q2: Histogram Eşitleme (30 puan)

### 4.1 Teorik Açıklama

Histogram eşitleme (histogram equalization), görüntünün kontrastını artırmak için kullanılan bir tekniktir. İşlem, görüntünün histogramını daha düzgün bir dağılıma dönüştürür.

**Matematiksel Formül:**

Kümülatif dağılım fonksiyonu (CDF):
```
CDF(i) = Σ(k=0 to i) H(k)
```

Eşitleme transformasyonu:
```
T(i) = round((CDF(i) - CDF_min) / (M×N - CDF_min) × 255)
```

Burada:
- `H(k)`: Histogram değeri
- `CDF_min`: Sıfır olmayan ilk CDF değeri
- `M×N`: Toplam piksel sayısı (16,384)

### 4.2 Implementasyon

**Adım 1: LUT (Look-Up Table) Oluşturma**

```c
static void build_equalization_lut(const uint32_t hist[256], int total,
                                   uint8_t lut[256]) {
  uint32_t cumulative = 0;
  uint32_t cdf_min = 0;
  uint32_t total_u = (uint32_t)total;

  for (int i = 0; i < 256; ++i) {
    cumulative += hist[i];
    if (cdf_min == 0 && cumulative != 0) {
      cdf_min = cumulative;
    }

    uint32_t v = 0;
    uint32_t denom = total_u - cdf_min;
    if (denom != 0U) {
      v = (cumulative - cdf_min) * 255u / denom;
    }
    if (v > 255u) v = 255u;
    lut[i] = (uint8_t)v;
  }
}
```

**Adım 2: Görüntüyü Eşitleme**

```c
// LUT kullanarak eşitlenmiş görüntü oluştur
for (int y = 0; y < IMG_H; ++y) {
  for (int x = 0; x < IMG_W; ++x) {
    uint8_t eq_val = lut[IMG[y * IMG_W + x]];
    // Eşitlenmiş piksel değeri
  }
}
```

**Algoritma:**
1. Orijinal histogramdan CDF hesaplanır
2. CDF'den eşitleme LUT'u oluşturulur
3. Her piksel, LUT kullanılarak eşitlenmiş değere dönüştürülür
4. Eşitlenmiş görüntünün histogramı hesaplanır

### 4.3 Sonuçlar

- **Eşitlenmiş Görüntü:** `img_eq[1024]` (ilk 1024 piksel)
- **Eşitlenmiş Histogram:** `hist_equalized[256]`
- **Beklenen Etki:** 
  - Kontrast artışı
  - Histogram dağılımının daha düzgün hale gelmesi
  - Düşük kontrastlı bölgelerin iyileştirilmesi

**STM32CubeIDE'de Görüntüleme:**
- `hist_equalized`: Eşitlenmiş görüntünün histogramı
- `img_eq[0...1023]`: Eşitlenmiş görüntünün ilk 1024 pikseli

---

## 5. Q3: 2D Konvolüsyon ve Filtreleme (30 puan)

### 5.1 Teorik Açıklama

2D konvolüsyon, bir görüntü üzerinde filtreleme işlemi yapmak için kullanılan temel işlemdir. Bir kernel (filtre matrisi) görüntü üzerinde kaydırılarak her piksel için yeni bir değer hesaplanır.

**Matematiksel Formül:**

```
I_out(x,y) = Σ(i=-1 to 1) Σ(j=-1 to 1) K(i,j) × I_in(x+i, y+j)
```

Burada:
- `I_in`: Giriş görüntüsü
- `I_out`: Çıkış görüntüsü
- `K`: 3×3 kernel matrisi

### 5.2 Low-Pass Filtre

**Amaç:** Yüksek frekanslı gürültüyü azaltmak, görüntüyü yumuşatmak

**Kernel:**
```
[1  1  1]
[1  1  1]  / 9
[1  1  1]
```

**Implementasyon:**

```c
// 3×3 pencere için ortalama hesaplama
int sum_lp = row_top[x-1] + row_top[x] + row_top[x+1] +
             row_mid[x-1] + row_mid[x] + row_mid[x+1] +
             row_bot[x-1] + row_bot[x] + row_bot[x+1];
uint8_t lp_val = (uint8_t)(sum_lp / 9);
```

**Etki:**
- Görüntü yumuşatılır
- Detaylar azalır, kenarlar bulanıklaşır
- Gürültü azalır

### 5.3 High-Pass Filtre

**Amaç:** Kenarları vurgulamak, düşük frekanslı bileşenleri bastırmak

**Kernel:**
```
[ 0  -1   0]
[-1   4  -1]
[ 0  -1   0]
```

**Implementasyon:**

```c
int hp_sum = 0;
hp_sum += -row_mid[x-1];
hp_sum += -row_mid[x+1];
hp_sum += -row_top[x];
hp_sum += -row_bot[x];
hp_sum += row_mid[x] * 4;
uint8_t hp_val = clamp_u8(hp_sum);
```

**Etki:**
- Kenarlar vurgulanır
- Düz bölgeler koyulaşır
- Yüksek frekanslı detaylar öne çıkar

### 5.4 Optimizasyon: Sliding Window Yaklaşımı

RAM kullanımını minimize etmek için, tam görüntü yerine sadece 3 satır buffer kullanılmıştır:

```c
uint8_t row_buf[3][IMG_W];  // Sadece 3 satır buffer

for (int y = 0; y < IMG_H; ++y) {
  uint8_t* row = row_buf[y % 3];  // Döngüsel buffer
  // İşlemler...
}
```

Bu yaklaşım sayesinde:
- **Önceki Yöntem:** 128×128×4 = 65,536 byte RAM
- **Yeni Yöntem:** 3×128 = 384 byte RAM
- **Tasarruf:** %99.4 RAM tasarrufu

### 5.5 Sonuçlar

- **Low-Pass Filtre:** `img_lp[1024]` (ilk 1024 piksel)
- **High-Pass Filtre:** `img_hp[1024]` (ilk 1024 piksel)
- **Giriş:** Eşitlenmiş görüntü (`img_eq`)

**STM32CubeIDE'de Görüntüleme:**
- `img_lp[0...1023]`: Low-pass filtrelenmiş görüntü
- `img_hp[0...1023]`: High-pass filtrelenmiş görüntü

---

## 6. Q4: Median Filtreleme (20 puan)

### 6.1 Teorik Açıklama

Median filtre, non-linear bir filtreleme yöntemidir. Her piksel için, 3×3 komşuluk bölgesindeki piksel değerlerinin medyanı (ortadaki değer) alınır.

**Avantajları:**
- Salt-and-pepper gürültüsünü etkili şekilde temizler
- Kenarları korur (linear filtrelerden farklı olarak)
- Impulse gürültüye karşı dayanıklıdır

**Algoritma:**
1. 3×3 pencere içindeki 9 piksel değeri toplanır
2. Değerler küçükten büyüğe sıralanır
3. Ortadaki değer (5. sıradaki, index 4) medyan olarak alınır

### 6.2 Implementasyon

```c
// 3×3 pencereyi topla
uint8_t window[9] = {
    row_top[x-1], row_top[x], row_top[x+1],
    row_mid[x-1], row_mid[x], row_mid[x+1],
    row_bot[x-1], row_bot[x], row_bot[x+1],
};

// Bubble sort ile sırala
for (int i = 0; i < 9; ++i) {
  for (int j = i + 1; j < 9; ++j) {
    if (window[j] < window[i]) {
      uint8_t tmp = window[i];
      window[i] = window[j];
      window[j] = tmp;
    }
  }
}

// Medyan değer (ortadaki eleman)
uint8_t med_val = window[4];
```

**Karmaşıklık:** O(9²) = O(81) işlem per piksel (bubble sort)

**Optimizasyon Notu:** Daha büyük görüntüler için QuickSelect veya histogram tabanlı median hesaplama kullanılabilir.

### 6.3 Sonuçlar

- **Median Filtre Çıktısı:** `img_med[1024]` (ilk 1024 piksel)
- **Giriş:** Eşitlenmiş görüntü (`img_eq`)

**STM32CubeIDE'de Görüntüleme:**
- `img_med[0...1023]`: Median filtrelenmiş görüntü

---

## 7. Kod Yapısı ve Organizasyon

### 7.1 Dosya Yapısı

```
imgtransfer/
├── Core/
│   ├── Inc/
│   │   ├── main.h
│   │   ├── mouse_image.h      # 128×128 görüntü verisi
│   │   └── ...
│   └── Src/
│       ├── main.c              # Ana program ve görüntü işleme fonksiyonları
│       └── ...
└── ...
```

### 7.2 Ana Fonksiyonlar

1. **`compute_histogram()`**: Histogram hesaplama
2. **`build_equalization_lut()`**: Histogram eşitleme LUT'u oluşturma
3. **`run_image_ops()`**: Tüm görüntü işlemlerini çalıştırma
4. **`store_window_value()`**: Piksel değerlerini buffer'a kaydetme

### 7.3 Veri Yapıları

```c
// Histogramlar
volatile uint32_t hist_original[256];    // Orijinal histogram
volatile uint32_t hist_equalized[256];   // Eşitlenmiş histogram

// Görüntü buffer'ları (ilk 1024 piksel)
volatile uint8_t first_pixels[20];       // İlk 20 piksel (kontrol)
volatile uint8_t img_eq[1024];           // Eşitlenmiş görüntü
volatile uint8_t img_lp[1024];           // Low-pass filtrelenmiş
volatile uint8_t img_hp[1024];           // High-pass filtrelenmiş
volatile uint8_t img_med[1024];          // Median filtrelenmiş
```

### 7.4 RAM Optimizasyonu

**Sorun:** 128×128 görüntü = 16,384 piksel. Tüm işlemler için buffer'lar RAM'de saklanırsa:
- Eşitlenmiş görüntü: 16,384 byte
- Low-pass: 16,384 byte
- High-pass: 16,384 byte
- Median: 16,384 byte
- **Toplam:** 65,536 byte (RAM taşması!)

**Çözüm:** 
- Sadece ilk 1024 piksel RAM'de saklanıyor
- 3 satır sliding window kullanılıyor
- LUT tabanlı histogram eşitleme (tam görüntü buffer'ı gerektirmiyor)

**Sonuç:** RAM kullanımı ~5 KB'a düşürüldü.

---

## 8. Test ve Doğrulama

### 8.1 STM32CubeIDE Debug Kullanımı

1. **Breakpoint Yerleştirme:**
   - `main.c` satır 276 (`while (1)`) breakpoint koyulur
   - Program `run_image_ops()` tamamlandıktan sonra durur

2. **Expressions Penceresi:**
   Aşağıdaki değişkenler eklenir:
   - `hist_original`
   - `hist_equalized`
   - `img_eq`
   - `img_lp`
   - `img_hp`
   - `img_med`
   - `first_pixels`

3. **Değer Kontrolü:**
   - Her değişkenin değerleri Expressions penceresinde görüntülenir
   - Dizi elemanları `[0]`, `[1]`, ... şeklinde erişilebilir

### 8.2 UART Çıktısı

İlk 20 piksel değeri UART üzerinden gönderilir:
```
IMG[0]=216
IMG[1]=216
IMG[2]=216
...
IMG[19]=...
```

**UART Ayarları:**
- Baud Rate: 115200
- Data Bits: 8
- Stop Bits: 1
- Parity: None

### 8.3 Beklenen Sonuçlar

1. **Histogram:**
   - `hist_original` dizisinin toplamı = 16,384
   - Tüm değerler ≥ 0

2. **Histogram Eşitleme:**
   - `hist_equalized` dizisinin toplamı = 16,384
   - Eşitlenmiş histogram daha düzgün dağılıma sahip olmalı

3. **Filtreler:**
   - `img_lp`: Yumuşatılmış görüntü (düşük değer değişimleri)
   - `img_hp`: Kenar vurgulanmış görüntü (yüksek kontrast)
   - `img_med`: Gürültü azaltılmış görüntü

---

## 9. Sonuç ve Değerlendirme

### 9.1 Başarılar

✅ Tüm ödev gereksinimleri başarıyla implement edildi:
- Q1: Histogram oluşturma ✓
- Q2: Histogram eşitleme ✓
- Q3: Low-pass ve high-pass filtreleme ✓
- Q4: Median filtreleme ✓

✅ RAM kullanımı optimize edildi:
- Sliding window yaklaşımı ile %99.4 RAM tasarrufu
- STM32F446RE'nin 128 KB RAM'ine sığdı

✅ Kod yapısı temiz ve modüler:
- Her işlem ayrı fonksiyonlarda
- Okunabilir ve bakımı kolay kod

### 9.2 Zorluklar ve Çözümler

**Zorluk 1: RAM Taşması**
- **Sorun:** 512×512 görüntü için RAM yetersizdi
- **Çözüm:** 128×128 görüntüye geçildi ve sliding window kullanıldı

**Zorluk 2: Performans**
- **Sorun:** Tüm görüntü buffer'ları RAM'de saklanırsa yavaş
- **Çözüm:** Stream processing yaklaşımı ile tek geçişte tüm işlemler yapıldı

### 9.3 İyileştirme Önerileri

1. **Median Filtre Optimizasyonu:**
   - Bubble sort yerine QuickSelect algoritması kullanılabilir
   - Karmaşıklık O(9) → O(9) (ortalama durumda daha hızlı)

2. **DMA Kullanımı:**
   - UART veri gönderimi için DMA kullanılabilir
   - CPU yükü azalır

3. **Paralel İşleme:**
   - ARM Cortex-M4'ün DSP özellikleri kullanılabilir
   - SIMD komutları ile hızlandırma yapılabilir

### 9.4 Öğrenilenler

- Embedded sistemlerde bellek yönetimi kritik öneme sahip
- Algoritma seçimi, donanım kısıtlamalarına göre yapılmalı
- Stream processing, büyük veri setleri için etkili bir yaklaşım
- Debug teknikleri (breakpoint, expressions) görüntü işleme algoritmalarını doğrulamak için önemli

---

## 10. Referanslar

1. STMicroelectronics. (2024). *STM32F4xx HAL and Low-Layer Drivers User Manual*
2. Gonzalez, R. C., & Woods, R. E. (2018). *Digital Image Processing* (4th ed.). Pearson.
3. STMicroelectronics. (2024). *STM32CubeIDE User Guide*

---

## Ekler

### Ek A: Kod Özeti

Tüm görüntü işleme fonksiyonları `Core/Src/main.c` dosyasında bulunmaktadır.

### Ek B: Görüntü Verisi

Görüntü verisi `Core/Inc/mouse_image.h` dosyasında `mouse_image` dizisi olarak tanımlanmıştır.

### Ek C: Debug Konfigürasyonu

Debug ayarları `imgtransfer Debug.launch` dosyasında yapılandırılmıştır.

---

**Rapor Hazırlayan:** [İsim]  
**Tarih:** 2025  
**Ders:** EE 4065 - Embedded Digital Image Processing

