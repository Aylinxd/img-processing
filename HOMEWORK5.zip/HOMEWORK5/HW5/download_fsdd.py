"""
Free Spoken Digit Dataset (FSDD) Auto Download Script
Downloads FSDD dataset from GitHub and extracts to recordings folder
"""

import os
import sys
import urllib.request
import zipfile
import shutil

# Fix encoding for Windows console
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

def download_fsdd():
    """Download and extract FSDD dataset"""
    
    # Create folder
    dataset_dir = "recordings"
    if not os.path.exists(dataset_dir):
        os.makedirs(dataset_dir)
        print(f"Folder created: {dataset_dir}")
    
    # FSDD GitHub repository
    # Using the official FSDD repository
    fsdd_url = "https://github.com/Jakobovski/free-spoken-digit-dataset/archive/refs/heads/master.zip"
    zip_path = "fsdd-master.zip"
    extract_dir = "fsdd-master"
    
    # Check if recordings already exist
    if os.path.exists(dataset_dir) and len(os.listdir(dataset_dir)) > 0:
        print(f"[INFO] {dataset_dir} folder already contains files.")
        response = input("Do you want to re-download? (y/n): ")
        if response.lower() != 'y':
            print("[SKIP] Download skipped.")
            return True
    
    try:
        print("=" * 60)
        print("Downloading FSDD Dataset...")
        print("=" * 60)
        print(f"\n[DOWNLOAD] {fsdd_url}...")
        
        # Download zip file
        urllib.request.urlretrieve(fsdd_url, zip_path)
        print(f"   [OK] Download completed")
        
        # Extract zip file
        print(f"\n[EXTRACT] Extracting {zip_path}...")
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(".")
        print(f"   [OK] Extraction completed")
        
        # Copy recordings to target directory
        source_recordings = os.path.join(extract_dir, "recordings")
        if os.path.exists(source_recordings):
            print(f"\n[COPY] Copying recordings to {dataset_dir}...")
            
            # Clear existing recordings if any
            if os.path.exists(dataset_dir):
                shutil.rmtree(dataset_dir)
            os.makedirs(dataset_dir)
            
            # Copy all files
            for file in os.listdir(source_recordings):
                src = os.path.join(source_recordings, file)
                dst = os.path.join(dataset_dir, file)
                if os.path.isfile(src):
                    shutil.copy2(src, dst)
            
            print(f"   [OK] {len(os.listdir(dataset_dir))} files copied")
        else:
            print(f"   [WARNING] {source_recordings} not found in extracted files")
            print("   [INFO] Trying alternative structure...")
            
            # Try alternative: recordings might be in root
            alt_source = os.path.join(extract_dir, "recordings")
            if not os.path.exists(alt_source):
                # List extracted directory structure
                print("\n[INFO] Extracted directory structure:")
                for root, dirs, files in os.walk(extract_dir):
                    level = root.replace(extract_dir, '').count(os.sep)
                    indent = ' ' * 2 * level
                    print(f'{indent}{os.path.basename(root)}/')
                    subindent = ' ' * 2 * (level + 1)
                    for file in files[:5]:  # Show first 5 files
                        print(f'{subindent}{file}')
                    if len(files) > 5:
                        print(f'{subindent}... and {len(files) - 5} more files')
        
        # Cleanup
        print(f"\n[CLEANUP] Removing temporary files...")
        if os.path.exists(zip_path):
            os.remove(zip_path)
        if os.path.exists(extract_dir):
            shutil.rmtree(extract_dir)
        print(f"   [OK] Cleanup completed")
        
        print("\n" + "=" * 60)
        print("[SUCCESS] FSDD dataset downloaded and extracted!")
        print("=" * 60)
        print(f"\nFiles are in: {os.path.abspath(dataset_dir)}")
        print(f"Total files: {len(os.listdir(dataset_dir))}")
        
        return True
        
    except Exception as e:
        print(f"\n[ERROR] {e}")
        if os.path.exists(zip_path):
            os.remove(zip_path)
        if os.path.exists(extract_dir):
            shutil.rmtree(extract_dir)
        return False

if __name__ == "__main__":
    success = download_fsdd()
    if success:
        print("\n[SUCCESS] You can now run 'python q1_train.py' to start training!")
    else:
        print("\n[ERROR] Download failed. Please check your internet connection.")
        print("\n[INFO] Alternative: You can manually download FSDD from:")
        print("       https://github.com/Jakobovski/free-spoken-digit-dataset")
        print("       And extract recordings folder to the project directory.")


