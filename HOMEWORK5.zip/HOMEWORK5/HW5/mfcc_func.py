"""
MFCC Feature Extraction Functions
Based on Section 5.5 from the textbook
"""

import os
import numpy as np
import scipy.io.wavfile as wavfile
import scipy.signal as sig
from scipy.fftpack import dct

def create_mfcc_features(recordings_list, FFTSize, sample_rate, numOfMelFilters, numOfDctOutputs, window):
    """
    Create MFCC features from audio recordings
    
    Args:
        recordings_list: List of (directory, filename) tuples
        FFTSize: FFT window size
        sample_rate: Audio sample rate
        numOfMelFilters: Number of Mel filters
        numOfDctOutputs: Number of DCT coefficients
        window: Window function (e.g., Hamming window)
    
    Returns:
        features: MFCC feature matrix
        labels: Corresponding labels
    """
    features_list = []
    labels_list = []
    
    for recording_dir, recording_file in recordings_list:
        filepath = os.path.join(recording_dir, recording_file)
        
        if not os.path.exists(filepath):
            print(f"Warning: File not found: {filepath}")
            continue
        
        # Read audio file
        try:
            fs, audio_data = wavfile.read(filepath)
            
            # Convert to mono if stereo
            if len(audio_data.shape) > 1:
                audio_data = np.mean(audio_data, axis=1)
            
            # Normalize audio
            audio_data = audio_data.astype(np.float32)
            if np.max(np.abs(audio_data)) > 0:
                audio_data = audio_data / np.max(np.abs(audio_data))
            
            # Extract MFCC features
            mfcc_features = extract_mfcc(audio_data, fs, FFTSize, numOfMelFilters, numOfDctOutputs, window)
            
            # Extract label from filename (e.g., "0_jackson_0.wav" -> 0)
            label = extract_label_from_filename(recording_file)
            
            if label is not None:
                features_list.append(mfcc_features)
                labels_list.append(label)
        
        except Exception as e:
            print(f"Error processing {filepath}: {e}")
            continue
    
    if len(features_list) == 0:
        raise ValueError("No valid audio files found!")
    
    features = np.array(features_list)
    labels = np.array(labels_list)
    
    return features, labels


def extract_mfcc(audio_data, sample_rate, FFTSize, numOfMelFilters, numOfDctOutputs, window):
    """
    Extract MFCC features from audio signal
    
    Args:
        audio_data: Audio signal array
        sample_rate: Sample rate
        FFTSize: FFT window size
        numOfMelFilters: Number of Mel filters
        numOfDctOutputs: Number of DCT coefficients
        window: Window function
    
    Returns:
        mfcc_features: MFCC feature vector (numOfDctOutputs * 2)
    """
    # Pre-emphasis filter
    pre_emphasis = 0.97
    emphasized_audio = np.append(audio_data[0], audio_data[1:] - pre_emphasis * audio_data[:-1])
    
    # Frame the signal
    frame_length = FFTSize
    frame_step = frame_length // 2  # 50% overlap
    num_frames = int(np.ceil((len(emphasized_audio) - frame_length) / frame_step)) + 1
    
    # Pad audio if necessary
    if len(emphasized_audio) < frame_length:
        emphasized_audio = np.pad(emphasized_audio, (0, frame_length - len(emphasized_audio)), mode='constant')
    
    # Initialize feature array
    mfcc_frames = []
    
    for i in range(num_frames):
        start = i * frame_step
        end = start + frame_length
        
        if end > len(emphasized_audio):
            frame = emphasized_audio[start:]
            frame = np.pad(frame, (0, frame_length - len(frame)), mode='constant')
        else:
            frame = emphasized_audio[start:end]
        
        # Apply window
        if len(window) == frame_length:
            frame = frame * window
        else:
            # Create window if size doesn't match
            window_frame = sig.get_window("hamming", frame_length)
            frame = frame * window_frame
        
        # FFT
        fft_frame = np.abs(np.fft.fft(frame, n=FFTSize))
        fft_frame = fft_frame[:FFTSize//2 + 1]  # Take only positive frequencies
        
        # Mel filter bank
        mel_energies = apply_mel_filterbank(fft_frame, sample_rate, FFTSize, numOfMelFilters)
        
        # Log of mel energies
        log_mel_energies = np.log(mel_energies + 1e-10)  # Add small value to avoid log(0)
        
        # DCT (Discrete Cosine Transform) - MFCC
        mfcc = dct(log_mel_energies, type=2, norm='ortho')[:numOfDctOutputs]
        
        mfcc_frames.append(mfcc)
    
    # Average over frames and concatenate with delta features
    mfcc_mean = np.mean(mfcc_frames, axis=0)
    
    # Calculate delta (first derivative)
    if len(mfcc_frames) > 1:
        delta = np.diff([mfcc_mean] + mfcc_frames, axis=0)
        delta_mean = np.mean(delta, axis=0)
    else:
        delta_mean = np.zeros_like(mfcc_mean)
    
    # Concatenate MFCC and delta features (26 features total: 13 + 13)
    mfcc_features = np.concatenate([mfcc_mean, delta_mean])
    
    return mfcc_features


def apply_mel_filterbank(fft_frame, sample_rate, FFTSize, numOfMelFilters):
    """
    Apply Mel filter bank to FFT spectrum
    
    Args:
        fft_frame: FFT magnitude spectrum
        sample_rate: Sample rate
        FFTSize: FFT size
        numOfMelFilters: Number of Mel filters
    
    Returns:
        mel_energies: Mel filter bank energies
    """
    # Convert frequency to Mel scale
    def hz_to_mel(hz):
        return 2595 * np.log10(1 + hz / 700.0)
    
    def mel_to_hz(mel):
        return 700 * (10**(mel / 2595.0) - 1)
    
    # Frequency range
    low_freq_mel = 0
    high_freq_mel = hz_to_mel(sample_rate / 2)
    
    # Create Mel filter points
    mel_points = np.linspace(low_freq_mel, high_freq_mel, numOfMelFilters + 2)
    hz_points = mel_to_hz(mel_points)
    
    # Convert to FFT bin indices
    bin_indices = np.floor((FFTSize + 1) * hz_points / sample_rate).astype(int)
    
    # Create filter bank
    filterbank = np.zeros((numOfMelFilters, len(fft_frame)))
    
    for i in range(numOfMelFilters):
        # Rising edge
        start = bin_indices[i]
        peak = bin_indices[i + 1]
        end = bin_indices[i + 2]
        
        for j in range(start, peak):
            if j < len(fft_frame):
                filterbank[i, j] = (j - start) / (peak - start) if peak != start else 0
        
        # Falling edge
        for j in range(peak, end):
            if j < len(fft_frame):
                filterbank[i, j] = (end - j) / (end - peak) if end != peak else 0
    
    # Apply filters
    mel_energies = np.dot(filterbank, fft_frame)
    
    return mel_energies


def extract_label_from_filename(filename):
    """
    Extract label from filename
    Expected format: "digit_speaker_number.wav" (e.g., "0_jackson_0.wav" -> 0)
    
    Args:
        filename: Audio filename
    
    Returns:
        label: Digit label (0-9) or None if not found
    """
    try:
        # Remove extension
        name = os.path.splitext(filename)[0]
        
        # Split by underscore and take first part
        parts = name.split('_')
        if len(parts) > 0:
            label = int(parts[0])
            if 0 <= label <= 9:
                return label
        
        # Alternative: try to find digit in filename
        for char in name:
            if char.isdigit() and 0 <= int(char) <= 9:
                return int(char)
        
        return None
    except:
        return None

