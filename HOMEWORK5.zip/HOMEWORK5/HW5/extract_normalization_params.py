"""
Extract normalization parameters (mean and std) from training data
These parameters are needed for feature normalization on STM32
"""

import os
import numpy as np
import cv2
from mnist import load_images, load_labels

def extract_hu_moments_normalization():
    """
    Extract mean and std from training data for Hu moments normalization
    This matches the normalization used in q2_train.py
    """
    print("Extracting normalization parameters for Hu Moments...")
    
    # Load training data
    train_img_path = os.path.join("MNIST-dataset", "train-images.idx3-ubyte")
    train_label_path = os.path.join("MNIST-dataset", "train-labels.idx1-ubyte")
    
    if not os.path.exists(train_img_path):
        print(f"ERROR: {train_img_path} not found!")
        print("Please download MNIST dataset first using download_mnist.py")
        return None, None
    
    print("Loading MNIST training data...")
    train_images = load_images(train_img_path)
    
    # Extract Hu moments features
    print("Extracting Hu moments features...")
    train_huMoments = np.empty((len(train_images), 7))
    
    for train_idx, train_img in enumerate(train_images):
        train_moments = cv2.moments(train_img, True)
        train_huMoments[train_idx] = cv2.HuMoments(train_moments).reshape(7)
    
    # Calculate mean and std
    features_mean = np.mean(train_huMoments, axis=0)
    features_std = np.std(train_huMoments, axis=0)
    
    print("\nNormalization parameters:")
    print(f"Mean: {features_mean}")
    print(f"Std: {features_std}")
    
    # Save to C header file
    output_path = "stm32_models/normalization_params.h"
    os.makedirs("stm32_models", exist_ok=True)
    
    with open(output_path, 'w') as f:
        f.write("/*\n")
        f.write(" * Normalization Parameters for Hu Moments Features\n")
        f.write(" * Extracted from MNIST training dataset\n")
        f.write(" * Used for feature normalization: (x - mean) / std\n")
        f.write(" */\n\n")
        f.write("#ifndef NORMALIZATION_PARAMS_H\n")
        f.write("#define NORMALIZATION_PARAMS_H\n\n")
        f.write("#include <stdint.h>\n\n")
        
        # Write mean array
        f.write("const float HU_MOMENTS_MEAN[7] = {\n")
        for i, m in enumerate(features_mean):
            f.write(f"    {m:.8f}f")
            if i < len(features_mean) - 1:
                f.write(",")
            f.write("\n")
        f.write("};\n\n")
        
        # Write std array
        f.write("const float HU_MOMENTS_STD[7] = {\n")
        for i, s in enumerate(features_std):
            f.write(f"    {s:.8f}f")
            if i < len(features_std) - 1:
                f.write(",")
            f.write("\n")
        f.write("};\n\n")
        
        f.write("#define NUM_HU_MOMENTS 7\n\n")
        f.write("#endif // NORMALIZATION_PARAMS_H\n")
    
    print(f"\nNormalization parameters saved to {output_path}")
    
    return features_mean, features_std


if __name__ == "__main__":
    mean, std = extract_hu_moments_normalization()
    if mean is not None and std is not None:
        print("\n" + "=" * 60)
        print("Normalization parameters extracted successfully!")
        print("=" * 60)

