"""
Extract normalization parameters (mean and std) from FSDD training data
These parameters are needed for MFCC feature normalization on STM32
"""

import os
import numpy as np
import scipy.signal as sig
from mfcc_func import create_mfcc_features

def extract_mfcc_normalization():
    """
    Extract mean and std from training data for MFCC features normalization
    This matches the normalization used in q1_train.py
    """
    print("Extracting normalization parameters for MFCC Features...")
    
    # FSDD dataset configuration
    RECORDINGS_DIR = "recordings"
    
    if not os.path.exists(RECORDINGS_DIR):
        print(f"ERROR: {RECORDINGS_DIR} directory not found!")
        print("Please download FSDD dataset first using download_fsdd.py")
        return None, None
    
    # Create recordings list
    recordings_list = [(RECORDINGS_DIR, recording_path) 
                       for recording_path in os.listdir(RECORDINGS_DIR)
                       if recording_path.endswith('.wav')]
    
    if len(recordings_list) == 0:
        print(f"ERROR: No .wav files found in {RECORDINGS_DIR}!")
        return None, None
    
    # Split into train and test sets
    test_list = {record for record in recordings_list if "yweweler" in record[1]}
    train_list = set(recordings_list) - test_list
    
    if len(train_list) == 0:
        print("ERROR: No training files found!")
        return None, None
    
    # MFCC parameters
    FFTSize = 1024
    sample_rate = 8000
    numOfMelFilters = 20
    numOfDctOutputs = 13
    window = sig.get_window("hamming", FFTSize)
    
    print("Loading FSDD training data...")
    print(f"Processing {len(train_list)} audio files...")
    
    # Extract MFCC features from training data
    train_mfcc_features, train_labels = create_mfcc_features(
        list(train_list), FFTSize, sample_rate, numOfMelFilters, numOfDctOutputs, window
    )
    
    # Calculate mean and std
    features_mean = np.mean(train_mfcc_features, axis=0)
    features_std = np.std(train_mfcc_features, axis=0)
    
    print("\nNormalization parameters:")
    print(f"Mean shape: {features_mean.shape}")
    print(f"Std shape: {features_std.shape}")
    print(f"Mean: {features_mean}")
    print(f"Std: {features_std}")
    
    # Save to C header file
    output_path = "stm32_models/audio_normalization_params.h"
    os.makedirs("stm32_models", exist_ok=True)
    
    with open(output_path, 'w') as f:
        f.write("/*\n")
        f.write(" * Normalization Parameters for MFCC Features\n")
        f.write(" * Extracted from FSDD training dataset\n")
        f.write(" * Used for feature normalization: (x - mean) / std\n")
        f.write(" */\n\n")
        f.write("#ifndef AUDIO_NORMALIZATION_PARAMS_H\n")
        f.write("#define AUDIO_NORMALIZATION_PARAMS_H\n\n")
        f.write("#include <stdint.h>\n\n")
        
        # Write mean array
        f.write(f"const float MFCC_FEATURES_MEAN[26] = {{\n")
        for i, m in enumerate(features_mean):
            f.write(f"    {m:.8f}f")
            if i < len(features_mean) - 1:
                f.write(",")
            f.write("\n")
        f.write("};\n\n")
        
        # Write std array
        f.write(f"const float MFCC_FEATURES_STD[26] = {{\n")
        for i, s in enumerate(features_std):
            f.write(f"    {s:.8f}f")
            if i < len(features_std) - 1:
                f.write(",")
            f.write("\n")
        f.write("};\n\n")
        
        f.write("#define NUM_MFCC_FEATURES 26\n\n")
        f.write("#endif // AUDIO_NORMALIZATION_PARAMS_H\n")
    
    print(f"\nNormalization parameters saved to {output_path}")
    
    return features_mean, features_std


if __name__ == "__main__":
    mean, std = extract_mfcc_normalization()
    if mean is not None and std is not None:
        print("\n" + "=" * 60)
        print("Normalization parameters extracted successfully!")
        print("=" * 60)


