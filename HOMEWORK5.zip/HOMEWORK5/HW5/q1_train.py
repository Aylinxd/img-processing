"""
Q1: Section 11.7 Application: Keyword Spotting from Audio Signals
Multilayer Neural Network for FSDD Dataset
Classes: 0-9 (10 classes - multi-class classification)

Based on Listing 11.5 from the textbook
"""

import os
import numpy as np
import scipy.signal as sig
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from sklearn.preprocessing import OneHotEncoder
import tensorflow as tf
from matplotlib import pyplot as plt
from mfcc_func import create_mfcc_features

# FSDD dataset configuration
RECORDINGS_DIR = "recordings"

# Check if recordings directory exists
if not os.path.exists(RECORDINGS_DIR):
    print(f"ERROR: {RECORDINGS_DIR} directory not found!")
    print("Please run 'python download_fsdd.py' first to download the dataset.")
    exit(1)

# Create recordings list
recordings_list = [(RECORDINGS_DIR, recording_path) 
                   for recording_path in os.listdir(RECORDINGS_DIR)
                   if recording_path.endswith('.wav')]

if len(recordings_list) == 0:
    print(f"ERROR: No .wav files found in {RECORDINGS_DIR}!")
    print("Please run 'python download_fsdd.py' first to download the dataset.")
    exit(1)

print(f"Found {len(recordings_list)} audio files")

# MFCC parameters (from Section 5.5)
FFTSize = 1024
sample_rate = 8000
numOfMelFilters = 20
numOfDctOutputs = 13
window = sig.get_window("hamming", FFTSize)

# Split into train and test sets
# Test set: files containing "yweweler" (as mentioned in the book)
test_list = {record for record in recordings_list if "yweweler" in record[1]}
train_list = set(recordings_list) - test_list

print(f"\nTrain set: {len(train_list)} files")
print(f"Test set: {len(test_list)} files")

if len(train_list) == 0:
    print("ERROR: No training files found!")
    exit(1)

if len(test_list) == 0:
    print("WARNING: No test files found with 'yweweler' in filename.")
    print("Using 20% of data as test set instead...")
    # Use 20% as test set
    test_size = int(len(recordings_list) * 0.2)
    test_list = set(list(recordings_list)[:test_size])
    train_list = set(recordings_list) - test_list
    print(f"Train set: {len(train_list)} files")
    print(f"Test set: {len(test_list)} files")

# Extract MFCC features
print("\nExtracting MFCC features from training set...")
train_mfcc_features, train_labels = create_mfcc_features(
    list(train_list), FFTSize, sample_rate, numOfMelFilters, numOfDctOutputs, window
)

print("\nExtracting MFCC features from test set...")
test_mfcc_features, test_labels = create_mfcc_features(
    list(test_list), FFTSize, sample_rate, numOfMelFilters, numOfDctOutputs, window
)

print(f"\nTrain features shape: {train_mfcc_features.shape}")
print(f"Test features shape: {test_mfcc_features.shape}")
print(f"Feature size: {train_mfcc_features.shape[1]} (should be 26: 13 MFCC + 13 delta)")

# Create multilayer neural network model (Section 11.7)
print("\nCreating multilayer neural network model...")
model = tf.keras.models.Sequential([
    tf.keras.layers.Dense(100, input_shape=[26], activation="relu"),
    tf.keras.layers.Dense(100, activation="relu"),
    tf.keras.layers.Dense(10, activation="softmax")
])

# One-hot encode training labels (categorical cross-entropy requires one-hot)
print("\nOne-hot encoding training labels...")
ohe = OneHotEncoder()
train_labels_ohe = ohe.fit_transform(train_labels.reshape(-1, 1)).toarray()

# Get unique categories for test labels
categories, test_labels_encoded = np.unique(test_labels, return_inverse=True)
print(f"Categories: {categories}")
print(f"Number of classes: {len(categories)}")

# Compile the model
print("\nCompiling model...")
model.compile(
    loss=tf.keras.losses.CategoricalCrossentropy(),
    optimizer=tf.keras.optimizers.Adam(1e-3)
)

# Print model summary
print("\nModel Summary:")
model.summary()

# Train the model
print("\nTraining the model...")
print("This may take a while...")
history = model.fit(
    train_mfcc_features,
    train_labels_ohe,
    epochs=100,
    verbose=1
)

# Make predictions
print("\nMaking predictions on test set...")
nn_preds = model.predict(test_mfcc_features)
predicted_classes = np.argmax(nn_preds, axis=1)

# Calculate confusion matrix
print("\nCalculating confusion matrix...")
conf_matrix = confusion_matrix(test_labels_encoded, predicted_classes)
print("\nConfusion Matrix:")
print(conf_matrix)

# Calculate accuracy
accuracy = np.trace(conf_matrix) / np.sum(conf_matrix)
print(f"\nTest Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")

# Display confusion matrix
cm_display = ConfusionMatrixDisplay(confusion_matrix=conf_matrix, display_labels=categories)
cm_display.plot()
cm_display.ax_.set_title("Neural Network Confusion Matrix - Keyword Spotting")
plt.tight_layout()
plt.savefig("q1_confusion_matrix.png", dpi=300, bbox_inches='tight')
print("\nConfusion matrix saved as 'q1_confusion_matrix.png'")
plt.close()  # Close figure instead of showing (prevents blocking)

# Print per-class accuracy
print("\nPer-class Accuracy:")
for i, category in enumerate(categories):
    class_correct = conf_matrix[i, i] if i < len(conf_matrix) else 0
    class_total = np.sum(conf_matrix[i, :]) if i < len(conf_matrix) else 0
    class_accuracy = class_correct / class_total if class_total > 0 else 0
    print(f"Class {category}: {class_correct}/{class_total} = {class_accuracy:.4f} ({class_accuracy*100:.2f}%)")

# Save the model
model_path = "mlp_fsdd_model.h5"
model.save(model_path)
print(f"\nModel saved as '{model_path}'")
print("Training completed!")

