"""
Export a test MNIST image to C array format for STM32 testing
"""

import os
import numpy as np
from mnist import load_images, load_labels

# Load MNIST test data
test_img_path = os.path.join("MNIST-dataset", "t10k-images.idx3-ubyte")
test_label_path = os.path.join("MNIST-dataset", "t10k-labels.idx1-ubyte")

print("Loading MNIST test data...")
test_images = load_images(test_img_path)
test_labels = load_labels(test_label_path)

# Select a few test images (one for each digit 0-9)
print("\nSelecting test images...")
test_samples = {}
for i in range(len(test_labels)):
    digit = test_labels[i]
    if digit not in test_samples:
        test_samples[digit] = test_images[i]
    if len(test_samples) == 10:
        break

# Export to C header file
output_file = "test_mnist_images.h"
print(f"\nExporting to {output_file}...")

with open(output_file, 'w') as f:
    f.write("/*\n")
    f.write(" * Test MNIST Images for Q2 Digit Recognition\n")
    f.write(" * Each image is 28x28 pixels (784 bytes)\n")
    f.write(" */\n\n")
    f.write("#ifndef TEST_MNIST_IMAGES_H\n")
    f.write("#define TEST_MNIST_IMAGES_H\n\n")
    f.write("#include <stdint.h>\n\n")
    
    # Export each digit
    for digit in sorted(test_samples.keys()):
        img = test_samples[digit]
        f.write(f"// Test image for digit {digit}\n")
        f.write(f"static const uint8_t test_image_{digit}[28 * 28] = {{\n")
        
        # Convert to uint8_t array
        img_flat = img.flatten().astype(np.uint8)
        
        # Write in rows of 16 bytes
        for i in range(0, len(img_flat), 16):
            row = img_flat[i:i+16]
            hex_values = ', '.join([f"0x{val:02X}" for val in row])
            if i + 16 < len(img_flat):
                f.write(f"    {hex_values},\n")
            else:
                f.write(f"    {hex_values}\n")
        
        f.write("};\n\n")
    
    # Create array of all test images
    f.write("// Array of all test images (index = digit)\n")
    f.write("static const uint8_t* test_images[10] = {\n")
    for digit in range(10):
        f.write(f"    test_image_{digit},\n")
    f.write("};\n\n")
    
    f.write("#endif // TEST_MNIST_IMAGES_H\n")

print(f"Exported {len(test_samples)} test images to {output_file}")
print("\nTest images:")
for digit in sorted(test_samples.keys()):
    print(f"  - Digit {digit}: OK")

