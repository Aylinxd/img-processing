"""
Convert Keras/TensorFlow model to C array for STM32
This script converts the trained models to C header files
"""

import numpy as np
import tensorflow as tf
import keras

def convert_model_to_c_array(model_path, output_header_path, model_name):
    """
    Convert Keras model weights to C array format
    
    Args:
        model_path: Path to .h5 model file
        output_header_path: Output .h file path
        model_name: Name for the model (used in variable names)
    """
    print(f"Loading model from {model_path}...")
    model = keras.models.load_model(model_path)
    
    print("Model architecture:")
    model.summary()
    
    # Get model weights
    weights = model.get_weights()
    
    # Generate C header file
    with open(output_header_path, 'w') as f:
        f.write(f"/*\n")
        f.write(f" * {model_name} Model Weights\n")
        f.write(f" * Auto-generated from {model_path}\n")
        f.write(f" * Model Architecture:\n")
        for i, layer in enumerate(model.layers):
            output_shape = getattr(layer, 'output_shape', 'Unknown')
            f.write(f" *   Layer {i}: {layer.__class__.__name__} - {output_shape}\n")
        f.write(f" */\n\n")
        f.write(f"#ifndef {model_name.upper()}_MODEL_H\n")
        f.write(f"#define {model_name.upper()}_MODEL_H\n\n")
        f.write(f"#include <stdint.h>\n\n")
        
        # Write weights for each layer
        weight_idx = 0
        for layer_idx, layer in enumerate(model.layers):
            if len(layer.get_weights()) > 0:
                # Get weights and biases
                layer_weights = weights[weight_idx]
                layer_biases = weights[weight_idx + 1] if weight_idx + 1 < len(weights) else None
                
                # Determine layer type
                layer_type = layer.__class__.__name__
                
                # Write weights
                if len(layer_weights.shape) == 2:  # Dense layer
                    input_size = layer_weights.shape[0]
                    output_size = layer_weights.shape[1]
                    
                    f.write(f"// Layer {layer_idx}: {layer_type}\n")
                    f.write(f"// Input size: {input_size}, Output size: {output_size}\n")
                    
                    # Flatten and write weights
                    weights_flat = layer_weights.flatten()
                    f.write(f"const float {model_name}_layer{layer_idx}_weights[{input_size * output_size}] = {{\n")
                    for i, w in enumerate(weights_flat):
                        if i % 8 == 0:
                            f.write("    ")
                        f.write(f"{w:.8f}f")
                        if i < len(weights_flat) - 1:
                            f.write(", ")
                        if (i + 1) % 8 == 0:
                            f.write("\n")
                    if len(weights_flat) % 8 != 0:
                        f.write("\n")
                    f.write("};\n\n")
                    
                    # Write biases
                    if layer_biases is not None:
                        f.write(f"const float {model_name}_layer{layer_idx}_biases[{output_size}] = {{\n")
                        for i, b in enumerate(layer_biases):
                            if i % 8 == 0:
                                f.write("    ")
                            f.write(f"{b:.8f}f")
                            if i < len(layer_biases) - 1:
                                f.write(", ")
                            if (i + 1) % 8 == 0:
                                f.write("\n")
                        if len(layer_biases) % 8 != 0:
                            f.write("\n")
                        f.write("};\n\n")
                    
                    # Store layer info
                    f.write(f"#define {model_name.upper()}_LAYER{layer_idx}_INPUT_SIZE {input_size}\n")
                    f.write(f"#define {model_name.upper()}_LAYER{layer_idx}_OUTPUT_SIZE {output_size}\n\n")
                    
                    weight_idx += 2
                else:
                    weight_idx += len(layer.get_weights())
        
        # Write normalization parameters (if needed)
        f.write(f"// Model configuration\n")
        f.write(f"#define {model_name.upper()}_NUM_LAYERS {len([l for l in model.layers if len(l.get_weights()) > 0])}\n")
        f.write(f"#define {model_name.upper()}_INPUT_SIZE {model.input_shape[1]}\n")
        f.write(f"#define {model_name.upper()}_OUTPUT_SIZE {model.output_shape[1]}\n\n")
        
        f.write(f"#endif // {model_name.upper()}_MODEL_H\n")
    
    print(f"Model converted successfully! Output: {output_header_path}")


def extract_normalization_params(train_data_path=None, mean=None, std=None):
    """
    Extract normalization parameters (mean and std) for features
    These should match the normalization used during training
    """
    if mean is not None and std is not None:
        return mean, std
    
    # If training data path is provided, calculate from data
    # Otherwise, return None (will need to be set manually)
    return None, None


def generate_model_config(model_path, output_config_path, model_name):
    """
    Generate model configuration C file from Keras model
    """
    import keras
    
    print(f"Loading model from {model_path}...")
    model = keras.models.load_model(model_path)
    
    # Get activation functions for each layer
    activations = []
    for layer in model.layers:
        if hasattr(layer, 'activation'):
            act = layer.activation
            if 'relu' in str(act).lower():
                activations.append('ACTIVATION_RELU')
            elif 'sigmoid' in str(act).lower():
                activations.append('ACTIVATION_SIGMOID')
            elif 'softmax' in str(act).lower():
                activations.append('ACTIVATION_SOFTMAX')
            else:
                activations.append('ACTIVATION_NONE')
        else:
            activations.append('ACTIVATION_NONE')
    
    # Count layers with weights
    layers_with_weights = [i for i, layer in enumerate(model.layers) if len(layer.get_weights()) > 0]
    num_layers = len(layers_with_weights)
    
    # Generate config file
    with open(output_config_path, 'w') as f:
        f.write("/**\n")
        f.write("  ******************************************************************************\n")
        f.write(f"  * @file    {output_config_path.split('/')[-1]}\n")
        f.write(f"  * @brief   {model_name} model configuration for STM32\n")
        f.write(f"  *          Auto-generated from {model_path}\n")
        f.write("  ******************************************************************************\n")
        f.write("  */\n\n")
        f.write(f"#include \"{model_name}_model_config.h\"\n")
        f.write("#include \"neural_network.h\"\n")
        f.write(f"#include \"{model_name}_model.h\"\n\n")
        
        # Write layer configurations
        for idx, layer_idx in enumerate(layers_with_weights):
            f.write(f"/* Layer {idx} configuration */\n")
            f.write(f"static const LayerConfig layer{idx} = {{\n")
            f.write(f"    .weights = {model_name}_layer{layer_idx}_weights,\n")
            f.write(f"    .biases = {model_name}_layer{layer_idx}_biases,\n")
            f.write(f"    .input_size = {model_name.upper()}_LAYER{layer_idx}_INPUT_SIZE,\n")
            f.write(f"    .output_size = {model_name.upper()}_LAYER{layer_idx}_OUTPUT_SIZE,\n")
            f.write(f"    .activation = {activations[layer_idx]}\n")
            f.write("};\n\n")
        
        # Write layers array
        f.write(f"static const LayerConfig* layers[{model_name.upper()}_NUM_LAYERS] = {{\n")
        for idx in range(num_layers):
            f.write(f"    &layer{idx}")
            if idx < num_layers - 1:
                f.write(",")
            f.write("\n")
        f.write("};\n\n")
        
        # Write model structure
        f.write(f"/* Model structure */\n")
        f.write(f"const NeuralNetworkModel {model_name}_model = {{\n")
        f.write(f"    .layers = (const LayerConfig*)layers,\n")
        f.write(f"    .num_layers = {model_name.upper()}_NUM_LAYERS,\n")
        f.write(f"    .input_size = {model_name.upper()}_INPUT_SIZE,\n")
        f.write(f"    .output_size = {model_name.upper()}_OUTPUT_SIZE\n")
        f.write("};\n")
    
    print(f"Model config generated successfully! Output: {output_config_path}")


if __name__ == "__main__":
    import os
    
    # Create stm32_models directory if it doesn't exist
    os.makedirs("stm32_models", exist_ok=True)
    
    # Convert Q1 model (Multilayer Neural Network for Keyword Spotting - FSDD)
    print("=" * 60)
    print("Converting Q1 Model: Multilayer Neural Network for Keyword Spotting")
    print("=" * 60)
    if os.path.exists("mlp_fsdd_model.h5"):
        convert_model_to_c_array(
            model_path="mlp_fsdd_model.h5",
            output_header_path="stm32_models/fsdd_mlp_model.h",
            model_name="fsdd_mlp"
        )
        generate_model_config(
            model_path="mlp_fsdd_model.h5",
            output_config_path="stm32_models/fsdd_mlp_model_config.c",
            model_name="fsdd_mlp"
        )
    else:
        print("WARNING: mlp_fsdd_model.h5 not found. Skipping Q1 model conversion.")
        print("         Run 'python q1_train.py' first to train the model.")
    
    # Convert Q2 model (Multilayer Neural Network for MNIST)
    print("\n" + "=" * 60)
    print("Converting Q2 Model: Multilayer Neural Network for MNIST")
    print("=" * 60)
    if os.path.exists("mlp_mnist_model.h5"):
        convert_model_to_c_array(
            model_path="mlp_mnist_model.h5",
            output_header_path="stm32_models/mnist_mlp_model.h",
            model_name="mnist_mlp"
        )
        generate_model_config(
            model_path="mlp_mnist_model.h5",
            output_config_path="stm32_models/mnist_mlp_model_config.c",
            model_name="mnist_mlp"
        )
    else:
        print("WARNING: mlp_mnist_model.h5 not found. Skipping Q2 model conversion.")
        print("         Run 'python q2_train.py' first to train the model.")
    
    print("\n" + "=" * 60)
    print("Model conversion completed!")
    print("=" * 60)
    print("\nNext steps:")
    print("1. Run extract_normalization_params.py to generate normalization parameters (for Q2)")
    print("2. Copy STM32 project files to your STM32CubeIDE workspace")
    print("3. Include the generated model files in your STM32 project")

