/**
  ******************************************************************************
  * @file    audio_features.h
  * @brief   Audio feature extraction header (MFCC, etc.)
  ******************************************************************************
  */

#ifndef AUDIO_FEATURES_H
#define AUDIO_FEATURES_H

#include <stdint.h>

/* Function prototypes */
void extract_audio_features(const int16_t* audio_samples, int num_samples, float* features);
void normalize_features(float* features, const float* mean, const float* std);

#endif /* AUDIO_FEATURES_H */

