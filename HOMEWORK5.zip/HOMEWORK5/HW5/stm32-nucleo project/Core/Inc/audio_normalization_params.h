/*
 * Normalization Parameters for MFCC Features
 * Extracted from FSDD training dataset
 * Used for feature normalization: (x - mean) / std
 */

#ifndef AUDIO_NORMALIZATION_PARAMS_H
#define AUDIO_NORMALIZATION_PARAMS_H

#include <stdint.h>

const float MFCC_FEATURES_MEAN[26] = {
    9.09892866f,
    -2.96912961f,
    -0.50904547f,
    -1.30605513f,
    -1.70346645f,
    -1.06478244f,
    -0.52209107f,
    -0.44398262f,
    -0.42692297f,
    -0.31455870f,
    -0.32711202f,
    -0.42453580f,
    -0.34288897f,
    -0.93890065f,
    -0.04763426f,
    0.08239054f,
    0.11336290f,
    0.11084520f,
    0.05188628f,
    0.00772490f,
    0.00600930f,
    0.00990863f,
    0.00259067f,
    0.01880103f,
    -0.00350677f,
    0.01413866f
};

const float MFCC_FEATURES_STD[26] = {
    3.11804127f,
    1.59159163f,
    1.12920659f,
    0.87091809f,
    0.68870113f,
    0.85805690f,
    0.48843239f,
    0.50092158f,
    0.35586331f,
    0.34549388f,
    0.32945974f,
    0.30326490f,
    0.24346719f,
    0.42165540f,
    0.24407282f,
    0.21621738f,
    0.15219704f,
    0.12737605f,
    0.11890739f,
    0.10343422f,
    0.07599343f,
    0.06395801f,
    0.06420269f,
    0.05503836f,
    0.05356492f,
    0.05169959f
};

#define NUM_MFCC_FEATURES 26

#endif // AUDIO_NORMALIZATION_PARAMS_H
