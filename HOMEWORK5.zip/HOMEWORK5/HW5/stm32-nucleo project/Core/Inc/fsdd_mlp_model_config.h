/**
  ******************************************************************************
  * @file    fsdd_mlp_model_config.h
  * @brief   FSDD MLP model configuration header for STM32
  ******************************************************************************
  */

#ifndef FSDD_MLP_MODEL_CONFIG_H
#define FSDD_MLP_MODEL_CONFIG_H

#include "neural_network.h"

/* External model declaration */
extern const NeuralNetworkModel fsdd_mlp_model;

#endif /* FSDD_MLP_MODEL_CONFIG_H */

