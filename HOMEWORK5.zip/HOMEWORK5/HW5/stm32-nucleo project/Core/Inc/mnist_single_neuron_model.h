/**
  ******************************************************************************
  * @file    mnist_single_neuron_model.h
  * @brief   MNIST Single Neuron Model Weights (Not used in Q2, kept for compatibility)
  ******************************************************************************
  */

#ifndef MNIST_SINGLE_NEURON_MODEL_H
#define MNIST_SINGLE_NEURON_MODEL_H

#include <stdint.h>

/* Dummy definitions - This model is not used in Q2 */
#define MNIST_SINGLE_LAYER0_INPUT_SIZE 7
#define MNIST_SINGLE_LAYER0_OUTPUT_SIZE 1
#define MNIST_SINGLE_NUM_LAYERS 1
#define MNIST_SINGLE_INPUT_SIZE 7
#define MNIST_SINGLE_OUTPUT_SIZE 1

/* Dummy arrays - Not used (defined in .c file if needed) */
extern const float mnist_single_layer0_weights[7];
extern const float mnist_single_layer0_biases[1];

#endif /* MNIST_SINGLE_NEURON_MODEL_H */

