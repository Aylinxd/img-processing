/**
  ******************************************************************************
  * @file    mnist_mlp_model_config.h
  * @brief   MNIST MLP model configuration header
  ******************************************************************************
  */

#ifndef MNIST_MLP_MODEL_CONFIG_H
#define MNIST_MLP_MODEL_CONFIG_H

#include "neural_network.h"

/* Forward declaration - model structure defined in .c file */
extern const NeuralNetworkModel mnist_mlp_model;

#endif /* MNIST_MLP_MODEL_CONFIG_H */

