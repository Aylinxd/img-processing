/**
  ******************************************************************************
  * @file    hu_moments.h
  * @brief   Hu Moments feature extraction header for STM32
  ******************************************************************************
  */

#ifndef HU_MOMENTS_H
#define HU_MOMENTS_H

#include <stdint.h>

/* Image moments structure */
typedef struct {
    float m00;      /* Zeroth moment (area) */
    float mu20;     /* Central moment (2,0) */
    float mu02;     /* Central moment (0,2) */
    float mu11;     /* Central moment (1,1) */
    float mu30;     /* Central moment (3,0) */
    float mu03;     /* Central moment (0,3) */
    float mu21;     /* Central moment (2,1) */
    float mu12;     /* Central moment (1,2) */
} ImageMoments;

/* Function prototypes */
void calculate_moments(const uint8_t* image, int width, int height, ImageMoments* moments);
void calculate_hu_moments(const ImageMoments* moments, float* hu_moments);
void extract_hu_moments(const uint8_t* image, int width, int height, float* hu_moments);
void normalize_hu_moments(float* hu_moments, const float* mean, const float* std);

#endif /* HU_MOMENTS_H */

