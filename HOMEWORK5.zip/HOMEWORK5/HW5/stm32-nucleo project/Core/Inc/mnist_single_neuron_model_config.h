/**
  ******************************************************************************
  * @file    mnist_single_neuron_model_config.h
  * @brief   MNIST Single Neuron model configuration header
  ******************************************************************************
  */

#ifndef MNIST_SINGLE_NEURON_MODEL_CONFIG_H
#define MNIST_SINGLE_NEURON_MODEL_CONFIG_H

#include "neural_network.h"

/* Forward declaration - model structure defined in .c file */
extern const NeuralNetworkModel mnist_single_neuron_model;

#endif /* MNIST_SINGLE_NEURON_MODEL_CONFIG_H */

