/**
  ******************************************************************************
  * @file    neural_network.h
  * @brief   Neural network inference header for STM32
  ******************************************************************************
  */

#ifndef NEURAL_NETWORK_H
#define NEURAL_NETWORK_H

#include <stdint.h>

/* Activation function types */
#define ACTIVATION_NONE    0
#define ACTIVATION_RELU    1
#define ACTIVATION_SIGMOID 2
#define ACTIVATION_SOFTMAX 3

/* Layer configuration structure */
typedef struct {
    const float* weights;      /* Weight matrix (flattened) */
    const float* biases;       /* Bias vector */
    int input_size;            /* Input vector size */
    int output_size;           /* Output vector size */
    int activation;            /* Activation function type */
} LayerConfig;

/* Neural network model structure */
typedef struct {
    const LayerConfig* layers; /* Array of layer configurations */
    int num_layers;            /* Number of layers */
    int input_size;           /* Input feature size */
    int output_size;          /* Output prediction size */
} NeuralNetworkModel;

/* Function prototypes */
void dense_layer_forward(const float* input, const float* weights, const float* biases,
                        float* output, int input_size, int output_size, int activation);
void neural_network_predict(const NeuralNetworkModel* model, const float* input, float* output);

/* Debug callback function type */
typedef void (*LayerProgressCallback)(int layer_idx, int total_layers);

#endif /* NEURAL_NETWORK_H */

