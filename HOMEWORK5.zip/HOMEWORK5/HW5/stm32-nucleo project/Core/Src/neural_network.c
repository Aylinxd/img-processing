/**
  ******************************************************************************
  * @file    neural_network.c
  * @brief   Neural network inference functions for STM32
  *          Implements forward pass for fully connected layers
  ******************************************************************************
  */

#include "neural_network.h"
#include <math.h>
#include <string.h>

/**
  * @brief  ReLU activation function
  * @param  x: Input value
  * @retval ReLU(x) = max(0, x)
  */
static float relu(float x) {
    return (x > 0.0f) ? x : 0.0f;
}

/**
  * @brief  Sigmoid activation function
  * @param  x: Input value
  * @retval Sigmoid(x) = 1 / (1 + exp(-x))
  */
static float sigmoid(float x) {
    // Clamp x to prevent overflow
    if (x > 10.0f) return 1.0f;
    if (x < -10.0f) return 0.0f;
    return 1.0f / (1.0f + expf(-x));
}

/**
  * @brief  Fast exponential approximation for embedded systems
  * @param  x: Input value
  * @retval Approximate exp(x) for small x
  */
static float fast_exp(float x) {
    // Clamp x to prevent overflow
    if (x > 5.0f) return 148.413f;  // exp(5) ≈ 148.413
    if (x < -5.0f) return 0.0067f;  // exp(-5) ≈ 0.0067
    
    // Taylor series approximation: exp(x) ≈ 1 + x + x²/2 + x³/6 + x⁴/24
    float x2 = x * x;
    float x3 = x2 * x;
    float x4 = x3 * x;
    return 1.0f + x + x2 * 0.5f + x3 * 0.16666667f + x4 * 0.04166667f;
}

/**
  * @brief  Softmax activation function
  * @param  input: Input array
  * @param  output: Output array (same size as input)
  * @param  size: Size of arrays
  * @retval None
  */
static void softmax(const float* input, float* output, int size) {
    float max_val = input[0];
    float sum = 0.0f;
    int i;
    
    // Find maximum value for numerical stability
    for (i = 1; i < size; i++) {
        if (input[i] > max_val) {
            max_val = input[i];
        }
    }
    
    // Compute exp(x - max) and sum - use only fast_exp for embedded systems
    for (i = 0; i < size; i++) {
        float diff = input[i] - max_val;
        // Clamp diff to reasonable range for fast_exp
        if (diff > 5.0f) diff = 5.0f;
        if (diff < -5.0f) diff = -5.0f;
        output[i] = fast_exp(diff);
        sum += output[i];
    }
    
    // Normalize
    if (sum > 0.0001f) {  // Avoid division by zero
        for (i = 0; i < size; i++) {
            output[i] /= sum;
        }
    } else {
        // Fallback: uniform distribution
        for (i = 0; i < size; i++) {
            output[i] = 1.0f / (float)size;
        }
    }
}

/**
  * @brief  Dense layer forward pass
  * @param  input: Input vector
  * @param  weights: Weight matrix (flattened, row-major)
  * @param  biases: Bias vector
  * @param  output: Output vector
  * @param  input_size: Size of input vector
  * @param  output_size: Size of output vector
  * @param  activation: Activation function type (0: none, 1: relu, 2: sigmoid, 3: softmax)
  * @retval None
  */
void dense_layer_forward(const float* input, const float* weights, const float* biases,
                        float* output, int input_size, int output_size, int activation) {
    int i, j;
    float sum;
    
    // Matrix multiplication: output = input * weights + biases
    // Weights are stored in row-major order: weights[input_size * output_size]
    // weights[j * output_size + i] = weight from input j to output i
    
    // Process output neurons
    // For large layers, process in chunks to avoid watchdog timeout
    for (i = 0; i < output_size; i++) {
        sum = biases[i];
        
        // Compute dot product: sum of input[j] * weights[j * output_size + i]
        // Optimize: unroll loop for small input sizes
        if (input_size <= 10) {
            // Small input: standard loop
            for (j = 0; j < input_size; j++) {
                sum += input[j] * weights[j * output_size + i];
            }
        } else {
            // Larger input: process in chunks
            for (j = 0; j < input_size; j++) {
                sum += input[j] * weights[j * output_size + i];
            }
        }
        
        output[i] = sum;
        
        // Apply activation
        switch (activation) {
            case ACTIVATION_RELU:
                if (output[i] < 0.0f) {
                    output[i] = 0.0f;
                }
                break;
            case ACTIVATION_SIGMOID:
                // Clamp to prevent overflow
                if (output[i] > 10.0f) {
                    output[i] = 1.0f;
                } else if (output[i] < -10.0f) {
                    output[i] = 0.0f;
                } else {
                    output[i] = 1.0f / (1.0f + expf(-output[i]));
                }
                break;
            case ACTIVATION_NONE:
            default:
                break;
        }
    }
    
    // Softmax is applied to entire output vector
    // TEMPORARILY DISABLED FOR DEBUGGING - use normalization instead
    if (activation == ACTIVATION_SOFTMAX) {
        // Skip softmax for now - just use raw values
        // softmax(output, output, output_size);
        // Instead, just normalize to [0,1] range for display
        float max_val = output[0];
        float min_val = output[0];
        int k;
        for (k = 1; k < output_size; k++) {
            if (output[k] > max_val) max_val = output[k];
            if (output[k] < min_val) min_val = output[k];
        }
        float range = max_val - min_val;
        if (range > 0.0001f) {
            for (k = 0; k < output_size; k++) {
                output[k] = (output[k] - min_val) / range;
            }
        }
    }
}

/**
  * @brief  Forward pass for multilayer neural network
  * @param  model: Pointer to neural network model structure
  * @param  input: Input feature vector
  * @param  output: Output prediction vector
  * @retval None
  */
void neural_network_predict(const NeuralNetworkModel* model, const float* input, float* output) {
    // Use static buffers to reduce stack usage
    static float temp_buffer1[100];   // Buffer for first hidden layer
    static float temp_buffer2[100];   // Buffer for second hidden layer (if exists)
    int layer_idx;
    const float* current_input = input;
    float* current_output;
    int i;
    
    // Validate model
    if (model == NULL || model->layers == NULL) {
        return;  // Invalid model
    }
    
    // Process each layer with progress indication
    for (layer_idx = 0; layer_idx < model->num_layers; layer_idx++) {
        const LayerConfig* layer = &model->layers[layer_idx];
        
        // Validate layer
        if (layer == NULL || layer->weights == NULL || layer->biases == NULL) {
            return;  // Invalid layer
        }
        
        // Determine output buffer
        if (layer_idx == model->num_layers - 1) {
            // Last layer: use final output buffer
            current_output = output;
        } else if (layer_idx == 0) {
            // First hidden layer
            current_output = temp_buffer1;
        } else {
            // Second hidden layer (if exists)
            current_output = temp_buffer2;
        }
        
        // Forward pass through layer
        // This is the potentially slow operation - process in smaller chunks
        dense_layer_forward(
            current_input,
            layer->weights,
            layer->biases,
            current_output,
            layer->input_size,
            layer->output_size,
            layer->activation
        );
        
        // Verify output is valid (not NaN or Inf)
        for (i = 0; i < layer->output_size; i++) {
            if (current_output[i] != current_output[i]) {  // NaN check
                // NaN detected - set to zero
                current_output[i] = 0.0f;
            }
            if (current_output[i] > 1e10f || current_output[i] < -1e10f) {  // Inf check
                // Very large value - clamp
                if (current_output[i] > 0) current_output[i] = 1e10f;
                else current_output[i] = -1e10f;
            }
        }
        
        // Next layer's input is this layer's output
        current_input = current_output;
    }
}

