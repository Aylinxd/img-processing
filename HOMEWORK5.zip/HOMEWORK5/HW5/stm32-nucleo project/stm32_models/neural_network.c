/**
  ******************************************************************************
  * @file    neural_network.c
  * @brief   Neural network inference functions for STM32
  *          Implements forward pass for fully connected layers
  ******************************************************************************
  */

#include "neural_network.h"
#include <math.h>
#include <string.h>

/**
  * @brief  ReLU activation function
  * @param  x: Input value
  * @retval ReLU(x) = max(0, x)
  */
static float relu(float x) {
    return (x > 0.0f) ? x : 0.0f;
}

/**
  * @brief  Sigmoid activation function
  * @param  x: Input value
  * @retval Sigmoid(x) = 1 / (1 + exp(-x))
  */
static float sigmoid(float x) {
    // Clamp x to prevent overflow
    if (x > 10.0f) return 1.0f;
    if (x < -10.0f) return 0.0f;
    return 1.0f / (1.0f + expf(-x));
}

/**
  * @brief  Softmax activation function
  * @param  input: Input array
  * @param  output: Output array (same size as input)
  * @param  size: Size of arrays
  * @retval None
  */
static void softmax(const float* input, float* output, int size) {
    float max_val = input[0];
    float sum = 0.0f;
    int i;
    
    // Find maximum value for numerical stability
    for (i = 1; i < size; i++) {
        if (input[i] > max_val) {
            max_val = input[i];
        }
    }
    
    // Compute exp(x - max) and sum
    for (i = 0; i < size; i++) {
        output[i] = expf(input[i] - max_val);
        sum += output[i];
    }
    
    // Normalize
    for (i = 0; i < size; i++) {
        output[i] /= sum;
    }
}

/**
  * @brief  Dense layer forward pass
  * @param  input: Input vector
  * @param  weights: Weight matrix (flattened, row-major)
  * @param  biases: Bias vector
  * @param  output: Output vector
  * @param  input_size: Size of input vector
  * @param  output_size: Size of output vector
  * @param  activation: Activation function type (0: none, 1: relu, 2: sigmoid, 3: softmax)
  * @retval None
  */
void dense_layer_forward(const float* input, const float* weights, const float* biases,
                        float* output, int input_size, int output_size, int activation) {
    int i, j;
    
    // Matrix multiplication: output = input * weights + biases
    for (i = 0; i < output_size; i++) {
        output[i] = biases[i];
        for (j = 0; j < input_size; j++) {
            output[i] += input[j] * weights[j * output_size + i];
        }
        
        // Apply activation
        switch (activation) {
            case ACTIVATION_RELU:
                output[i] = relu(output[i]);
                break;
            case ACTIVATION_SIGMOID:
                output[i] = sigmoid(output[i]);
                break;
            case ACTIVATION_NONE:
            default:
                break;
        }
    }
    
    // Softmax is applied to entire output vector
    if (activation == ACTIVATION_SOFTMAX) {
        softmax(output, output, output_size);
    }
}

/**
  * @brief  Forward pass for multilayer neural network
  * @param  model: Pointer to neural network model structure
  * @param  input: Input feature vector
  * @param  output: Output prediction vector
  * @retval None
  */
void neural_network_predict(const NeuralNetworkModel* model, const float* input, float* output) {
    float* layer_outputs[2];  // Intermediate layer outputs (max 2 hidden layers)
    float temp_buffer1[100];   // Buffer for first hidden layer
    float temp_buffer2[100];   // Buffer for second hidden layer (if exists)
    int layer_idx;
    const float* current_input = input;
    float* current_output;
    
    // Process each layer
    for (layer_idx = 0; layer_idx < model->num_layers; layer_idx++) {
        const LayerConfig* layer = &model->layers[layer_idx];
        
        // Determine output buffer
        if (layer_idx == model->num_layers - 1) {
            // Last layer: use final output buffer
            current_output = output;
        } else if (layer_idx == 0) {
            // First hidden layer
            current_output = temp_buffer1;
        } else {
            // Second hidden layer (if exists)
            current_output = temp_buffer2;
        }
        
        // Forward pass through layer
        dense_layer_forward(
            current_input,
            layer->weights,
            layer->biases,
            current_output,
            layer->input_size,
            layer->output_size,
            layer->activation
        );
        
        // Next layer's input is this layer's output
        current_input = current_output;
    }
}

